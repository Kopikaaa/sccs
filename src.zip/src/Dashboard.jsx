import { useState, useEffect, useRef } from "react";
import Navbar from "./Navbar";
import { auth, db } from "./firebase";
import {
  collection,
  addDoc,
  serverTimestamp,
  query,
  orderBy,
  onSnapshot,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
} from "firebase/firestore";

export default function Dashboard() {
  const [reportType, setReportType] = useState("normal");
  const [extraType, setExtraType] = useState("");
  const [fineAmount, setFineAmount] = useState("");
  const [vehicleType, setVehicleType] = useState("");
  const [plate, setPlate] = useState("");
  const [description, setDescription] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");
  const [reports, setReports] = useState([]);
  const [role, setRole] = useState("user");
  const [profile, setProfile] = useState(null);
  const [topUsers, setTopUsers] = useState([]);
  const [selectedImage, setSelectedImage] = useState(null);
  const [usersMap, setUsersMap] = useState({});
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    const loadProfile = async () => {
      if (!auth.currentUser) return;
      try {
        const userRef = doc(db, "users", auth.currentUser.uid);
        const snap = await getDoc(userRef);
        if (snap.exists()) {
          const data = snap.data();
          setProfile(data);
          setRole(data.role || "user");
        } else {
          setProfile({ username: auth.currentUser.displayName || "" });
        }
      } catch (err) {
        console.error("Profil betöltési hiba:", err);
      }
    };
    loadProfile();
  }, []);

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const snap = await getDocs(collection(db, "users"));
        const map = {};
        snap.docs.forEach((d) => {
          const data = d.data();
          map[d.id] = data.displayName || data.username || data.email || "";
        });
        setUsersMap(map);
      } catch (err) {
        console.error("Users load hiba:", err);
      }
    };
    loadUsers();

    const unsub = onSnapshot(collection(db, "users"), (s) => {
      const map = {};
      s.docs.forEach((d) => {
        const data = d.data();
        map[d.id] = data.displayName || data.username || data.email || "";
      });
      setUsersMap(map);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const q = query(collection(db, "reports"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setReports(list);

      const countMap = {};
      list.forEach((r) => {
        const nameFromMap = usersMap[r.userId];
        const name =
          nameFromMap || r.displayName || r.username || r.user || "Ismeretlen";
        countMap[name] = (countMap[name] || 0) + 1;
      });
      const sorted = Object.entries(countMap)
        .map(([name, count]) => ({ name, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);
      setTopUsers(sorted);
    });
    return () => unsub();
  }, [usersMap]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setUploadProgress(0);

    // Most már a kép kötelező
    if (!vehicleType.trim() || !plate.trim() || !imageFile) {
      setError("❌ Töltsd ki az összes mezőt és csatolj képet is!");
      return;
    }

    try {
      const imageUrl = imageFile ? imageFile.name : "";

      await addDoc(collection(db, "reports"), {
        reportType,
        extraType: reportType === "extra" ? extraType : null,
        fineAmount:
          reportType === "extra" && extraType === "fine"
            ? Number(fineAmount)
            : null,
        vehicleType,
        plate,
        description,
        imageUrl,
        userId: auth.currentUser?.uid,
        displayName:
          profile?.displayName ||
          profile?.username ||
          auth.currentUser?.displayName ||
          auth.currentUser?.email,
        createdAt: serverTimestamp(),
      });

      setSuccess("✅ Jelentés sikeresen beküldve!");
      setVehicleType("");
      setPlate("");
      setDescription("");
      setImageFile(null);
      setFineAmount("");
      setExtraType("");
      setReportType("normal");
      setUploadProgress(0);
    } catch (err) {
      console.error(err);
      setError("Hiba történt: " + err.message);
    }
  };

  const handleDelete = async (id) => {
    if (role !== "admin") {
      alert("Nincs jogosultságod!");
      return;
    }
    if (window.confirm("Biztosan törlöd?")) {
      await deleteDoc(doc(db, "reports", id));
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 pt-20">
      <Navbar />
      <main className="max-w-6xl mx-auto px-4 pb-12">
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <aside className="bg-gray-800 border border-gray-700 rounded-2xl p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-yellow-400 mb-3">
              🏆 Top jelentések
            </h3>
            <ul className="text-sm text-gray-300 space-y-1">
              {topUsers.length === 0 ? (
                <li className="text-gray-500">Még nincs adat</li>
              ) : (
                topUsers.map((u, i) => (
                  <li key={i}>
                    {i + 1}. {u.name} –{" "}
                    <span className="text-blue-300">{u.count}</span> jelentés
                  </li>
                ))
              )}
            </ul>
          </aside>

          <section className="lg:col-span-2 bg-gray-800 border border-gray-700 rounded-2xl p-6">
            <h1 className="text-2xl font-bold text-blue-300 mb-4">
              📝 Jelentés beküldése
            </h1>
            <form
              onSubmit={handleSubmit}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              <div className="md:col-span-2">
                <label className="block mb-1 text-gray-300">
                  Jelentés típusa:
                </label>
                <select
                  value={reportType}
                  onChange={(e) => setReportType(e.target.value)}
                  className="w-full p-3 border border-gray-700 rounded-lg bg-gray-900 text-gray-100"
                >
                  <option value="normal">Normál jelentés</option>
                  <option value="extra">Egyéb jelentés</option>
                </select>
              </div>

              {reportType === "extra" && (
                <div className="md:col-span-2">
                  <label className="block mb-1 text-gray-300">Egyéb típus:</label>
                  <select
                    value={extraType}
                    onChange={(e) => setExtraType(e.target.value)}
                    className="w-full p-3 border border-gray-700 rounded-lg bg-gray-900 text-gray-100"
                  >
                    <option value="">Válassz típust</option>
                    <option value="booking">Lefoglalás</option>
                    <option value="fine">Bírság</option>
                  </select>
                </div>
              )}

              {reportType === "extra" && extraType === "fine" && (
                <div className="md:col-span-2">
                  <label className="block mb-1 text-gray-300">
                    Bírság összege (Ft):
                  </label>
                  <input
                    type="number"
                    placeholder="Pl. 15000"
                    value={fineAmount}
                    onChange={(e) => setFineAmount(e.target.value)}
                    className="w-full p-3 border border-gray-700 rounded-lg bg-gray-900 text-gray-100"
                  />
                </div>
              )}

              <input
                type="text"
                placeholder="Gépjármű típusa"
                value={vehicleType}
                onChange={(e) => setVehicleType(e.target.value)}
                className="md:col-span-2 p-3 border border-gray-700 rounded-lg bg-gray-900 text-gray-100"
              />
              <input
                type="text"
                placeholder="Rendszám"
                value={plate}
                onChange={(e) => setPlate(e.target.value.toUpperCase())}
                className="p-3 border border-gray-700 rounded-lg bg-gray-900 text-gray-100"
              />

              <div className="p-2 border border-dashed border-gray-700 rounded-lg flex items-center justify-center bg-gray-950">
                <label className="w-full text-center cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setImageFile(e.target.files[0] || null)}
                    className="hidden"
                  />
                  <div className="text-sm text-gray-400">
                    Kattints ide vagy húzz egy képet ide
                  </div>
                  {imageFile && (
                    <div className="text-xs mt-2">{imageFile.name}</div>
                  )}
                </label>
              </div>

              <textarea
                placeholder="Megjegyzés (opcionális)"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="md:col-span-2 p-3 border border-gray-700 rounded-lg bg-gray-900 text-gray-100 resize-none h-24"
              />

              <button
                type="submit"
                className="col-span-2 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg"
              >
                Jelentés beküldése
              </button>
            </form>

            {uploadProgress > 0 && (
              <div className="w-full bg-gray-700 h-2 rounded-full mt-3">
                <div
                  className="h-2 bg-blue-500"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
            )}
            {success && <p className="mt-4 text-green-400">{success}</p>}
            {error && <p className="mt-4 text-red-400">{error}</p>}
          </section>
        </section>

        <section className="mt-8">
          <h2 className="text-xl font-semibold text-blue-300 mb-4">
            📋 Legutóbbi jelentések
          </h2>
          {reports.length === 0 ? (
            <div className="bg-gray-800 border border-gray-700 rounded-xl p-6 text-gray-400">
              Még nincs jelentés.
            </div>
          ) : (
            <div className="grid gap-4">
              {reports.map((r) => (
                <div
                  key={r.id}
                  className="bg-gray-800 border border-gray-700 rounded-xl p-4 flex gap-4"
                >
                  <div
                    className="w-20 h-20 bg-gray-900 rounded overflow-hidden flex items-center justify-center cursor-pointer hover:opacity-90"
                    onClick={() => setSelectedImage(r.imageUrl)}
                  >
                    {r.imageUrl ? (
                      <img
                        src={r.imageUrl}
                        alt="report"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="text-xs text-gray-500">Nincs kép</div>
                    )}
                  </div>
                  <div className="flex-1 text-sm text-gray-300">
                    <div className="font-semibold text-blue-200 mb-1">
                      🚗 {r.vehicleType}
                    </div>
                    <div>🔢 Rendszám: {r.plate}</div>
                    {r.reportType === "extra" && (
                      <>
                        <div>
                          📁 Típus:{" "}
                          {r.extraType === "booking"
                            ? "Lefoglalás"
                            : "Bírság"}
                        </div>
                        {r.extraType === "fine" && (
                          <div>💸 Bírság: {r.fineAmount} Ft</div>
                        )}
                      </>
                    )}
                    <div>📝 {r.description || "Nincs megjegyzés"}</div>
                    <div className="text-xs text-gray-400 mt-2">
                      {r.createdAt?.toDate
                        ? r.createdAt.toDate().toLocaleString()
                        : "Folyamatban..."}{" "}
                      – {usersMap[r.userId] || r.displayName || r.user}
                    </div>
                    {role === "admin" && (
                      <button
                        onClick={() => handleDelete(r.id)}
                        className="mt-2 bg-red-600 hover:bg-red-700 text-white text-xs px-3 py-1 rounded"
                      >
                        🗑️ Törlés
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      {selectedImage && (
        <div
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-50"
          onClick={() => setSelectedImage(null)}
        >
          <img
            src={selectedImage}
            alt="preview"
            className="max-w-3xl max-h-[90vh] rounded-lg shadow-2xl"
          />
        </div>
      )}
    </div>
  );
}
