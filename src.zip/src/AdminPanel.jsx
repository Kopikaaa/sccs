import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  doc,
  updateDoc,
  deleteDoc,
  addDoc,
  serverTimestamp,
  getDocs,
} from "firebase/firestore";
import Navbar from "./Navbar";

export default function AdminPanel() {
  const [reports, setReports] = useState([]);
  const [nameRequests, setNameRequests] = useState([]);
  const [pendingUsers, setPendingUsers] = useState([]);
  const [meetingSummary, setMeetingSummary] = useState([]);
  const [activeTab, setActiveTab] = useState("reports");
  const [loading, setLoading] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);

  // 🔹 Betöltés
  useEffect(() => {
    // Jelentések
    const qReports = query(collection(db, "reports"), orderBy("createdAt", "desc"));
    const unsubReports = onSnapshot(qReports, (snap) => {
      setReports(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });

    // Névváltoztatások
    const qNames = query(collection(db, "nameChangeRequests"), orderBy("timestamp", "desc"));
    const unsubNames = onSnapshot(qNames, (snap) => {
      setNameRequests(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });

    // Meeting összegző
    const qMeet = query(collection(db, "meetingSummary"), orderBy("createdAt", "desc"));
    const unsubMeet = onSnapshot(qMeet, (snap) => {
      setMeetingSummary(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });

    // Függő felhasználók
    const qUsers = query(collection(db, "users"), where("approved", "==", false));
    const unsubUsers = onSnapshot(qUsers, (snap) => {
      setPendingUsers(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });

    return () => {
      unsubReports();
      unsubNames();
      unsubMeet();
      unsubUsers();
    };
  }, []);

  // 🔹 Függő elemek számláló
  useEffect(() => {
    const total =
      (reports.length ? reports.length : 0) +
      (nameRequests.filter((n) => n.status === "pending").length || 0) +
      (pendingUsers.length || 0);
    setPendingCount(total);
  }, [reports, nameRequests, pendingUsers]);

  // 🔹 Felhasználó jóváhagyása
  const handleApproveUser = async (uid) => {
    try {
      await updateDoc(doc(db, "users", uid), { approved: true });
      await addDoc(collection(db, "notifications"), {
        target: uid,
        title: "✅ Fiók jóváhagyva",
        body: "Az admin jóváhagyta a regisztrációdat. Most már be tudsz lépni.",
        createdAt: serverTimestamp(),
        readBy: [],
      });

      // Állapot frissítés
      setPendingUsers((prev) => prev.filter((u) => u.id !== uid));

      alert("Felhasználó jóváhagyva!");
    } catch (err) {
      console.error(err);
      alert("Hiba a jóváhagyás során: " + err.message);
    }
  };

  // 🔹 Jelentés törlés
  const handleDeleteReport = async (id) => {
    if (!window.confirm("Biztosan törölni szeretnéd a jelentést?")) return;
    try {
      await deleteDoc(doc(db, "reports", id));
      setReports((prev) => prev.filter((r) => r.id !== id)); // Lista frissítése
      alert("Jelentés törölve!");
    } catch (err) {
      console.error(err);
      alert("Hiba a törlés során.");
    }
  };

  // 🔹 Név elfogadás
  const handleApproveName = async (req) => {
    try {
      const userRef = doc(db, "users", req.userId);
      await updateDoc(userRef, { displayName: req.newName });
      await updateDoc(doc(db, "nameChangeRequests", req.id), { status: "approved" });

      await addDoc(collection(db, "notifications"), {
        target: req.userId,
        title: "✅ Névváltoztatás elfogadva",
        body: `Az új neved: ${req.newName}`,
        createdAt: serverTimestamp(),
        readBy: [],
      });

      // 🔹 Lista frissítés: eltávolítjuk a kérelmet
      setNameRequests((prev) => prev.filter((r) => r.id !== req.id));

      alert("Névváltoztatás elfogadva és frissítve!");
    } catch (err) {
      console.error(err);
      alert("Hiba: " + err.message);
    }
  };

  // 🔹 Név elutasítás
  const handleRejectName = async (req) => {
    try {
      await updateDoc(doc(db, "nameChangeRequests", req.id), { status: "rejected" });

      await addDoc(collection(db, "notifications"), {
        target: req.userId,
        title: "❌ Névváltoztatás elutasítva",
        body: "Az admin elutasította a kérelmedet.",
        createdAt: serverTimestamp(),
        readBy: [],
      });

      // 🔹 Lista frissítés: eltávolítjuk az elutasított kérelmet
      setNameRequests((prev) => prev.filter((r) => r.id !== req.id));

      alert("Elutasítva.");
    } catch (err) {
      console.error(err);
      alert("Hiba: " + err.message);
    }
  };

  // 🔹 Meeting összegző generálás
  const handleGenerateSummary = async () => {
    try {
      const reportsSnap = await getDocs(collection(db, "reports"));
      const reportsData = reportsSnap.docs.map((doc) => doc.data());
      const summaryText = `Összes jelentés: ${reportsData.length}`;
      await addDoc(collection(db, "meetingSummary"), {
        text: summaryText,
        createdAt: serverTimestamp(),
      });
      alert("Meeting összegző frissítve!");
    } catch (err) {
      console.error(err);
      alert("Hiba: " + err.message);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-950 text-white">
        <p>Betöltés...</p>
      </div>
    );
  }

  // 🔹 Csak a függő státuszú kérelmeket mutatjuk
  const pendingNameRequests = nameRequests.filter((r) => r.status === "pending");

  return (
    <div className="min-h-screen bg-gray-950 text-white pt-20">
      <Navbar pendingCount={pendingCount} />
      <div className="max-w-6xl mx-auto p-6">
        <h1 className="text-3xl font-bold text-blue-400 mb-6 text-center">
          🛡️ Admin Kezelőfelület
        </h1>

        {/* Navigációs tabok */}
        <div className="flex justify-center gap-4 mb-8">
          {[
            ["reports", "📋 Jelentések"],
            ["users", "👥 Jóváhagyás"],
            ["names", "✏️ Névkérelmek"],
            ["summary", "📅 Meeting összegző"],
          ].map(([key, label]) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`px-4 py-2 rounded-lg font-semibold transition ${
                activeTab === key
                  ? "bg-blue-600"
                  : "bg-gray-800 hover:bg-gray-700"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Jelentések */}
        {activeTab === "reports" && (
          <div className="bg-gray-900 rounded-xl p-6 shadow-lg border border-gray-700">
            <h2 className="text-xl font-bold mb-4 text-blue-300">
              📋 Beérkezett jelentések
            </h2>
            {reports.length === 0 ? (
              <p className="text-gray-400 text-sm">Nincs jelentés.</p>
            ) : (
              reports.map((r) => (
                <div
                  key={r.id}
                  className="border-t border-gray-700 py-3 flex justify-between"
                >
                  <div>
                    <p className="font-semibold">{r.reportType || "Normál"}</p>
                    <p className="text-gray-400 text-sm">{r.description || "Nincs leírás"}</p>
                    <p className="text-xs text-gray-500">
                      Beküldte: {r.displayName || "Ismeretlen"} |{" "}
                      {r.createdAt?.toDate
                        ? r.createdAt.toDate().toLocaleString()
                        : "N/A"}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteReport(r.id)}
                    className="bg-red-600 hover:bg-red-700 px-3 py-1 rounded-lg text-sm"
                  >
                    Törlés
                  </button>
                </div>
              ))
            )}
          </div>
        )}

        {/* Jóváhagyás */}
        {activeTab === "users" && (
          <div className="bg-gray-900 rounded-xl p-6 border border-gray-700 shadow-lg">
            <h2 className="text-xl font-bold mb-4 text-blue-300">
              👥 Jóváhagyásra váró felhasználók
            </h2>
            {pendingUsers.length === 0 ? (
              <p className="text-gray-400">Nincs függő felhasználó.</p>
            ) : (
              pendingUsers.map((u) => (
                <div
                  key={u.id}
                  className="flex justify-between items-center border-t border-gray-700 py-3"
                >
                  <div>
                    <p className="font-semibold">{u.displayName}</p>
                    <p className="text-sm text-gray-400">{u.email}</p>
                  </div>
                  <button
                    onClick={() => handleApproveUser(u.id)}
                    className="bg-green-600 hover:bg-green-700 px-4 py-1 rounded-lg text-sm"
                  >
                    Jóváhagy
                  </button>
                </div>
              ))
            )}
          </div>
        )}

        {/* Névkérelmek */}
        {activeTab === "names" && (
          <div className="bg-gray-900 rounded-xl p-6 border border-gray-700 shadow-lg">
            <h2 className="text-xl font-bold mb-4 text-blue-300">
              ✏️ Függő névváltoztatási kérelmek
            </h2>
            {pendingNameRequests.length === 0 ? (
              <p className="text-gray-400">Nincs függő kérelem.</p>
            ) : (
              pendingNameRequests.map((r) => (
                <div
                  key={r.id}
                  className="border-t border-gray-700 py-3 flex justify-between"
                >
                  <div>
                    <p>
                      <strong>Régi:</strong> {r.oldName} →{" "}
                      <strong>Új:</strong> {r.newName}
                    </p>
                    <p className="text-sm text-gray-400">Indok: {r.reason}</p>
                    <p className="text-xs text-gray-500">
                      Státusz: {r.status} |{" "}
                      {r.timestamp?.toDate
                        ? r.timestamp.toDate().toLocaleString()
                        : "N/A"}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleApproveName(r)}
                      className="bg-green-600 hover:bg-green-700 px-3 py-1 rounded text-sm"
                    >
                      Elfogad
                    </button>
                    <button
                      onClick={() => handleRejectName(r)}
                      className="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-sm"
                    >
                      Elutasít
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Meeting összegző */}
        {activeTab === "summary" && (
          <div className="bg-gray-900 rounded-xl p-6 border border-gray-700 shadow-lg">
            <h2 className="text-xl font-bold mb-4 text-blue-300">
              📅 Meeting összegző
            </h2>
            <button
              onClick={handleGenerateSummary}
              className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg mb-4"
            >
              Új összegző generálása
            </button>
            {meetingSummary.length === 0 ? (
              <p className="text-gray-400">Nincs összegző adat.</p>
            ) : (
              meetingSummary.map((m) => (
                <div
                  key={m.id}
                  className="border-t border-gray-700 py-3 text-sm text-gray-300"
                >
                  <p>{m.text}</p>
                  <p className="text-xs text-gray-500">
                    {m.createdAt?.toDate
                      ? m.createdAt.toDate().toLocaleString()
                      : "N/A"}
                  </p>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
