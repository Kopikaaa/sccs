import React, { useEffect, useState } from "react";
import { auth, db } from "./firebase";
import { onAuthStateChanged, reload } from "firebase/auth";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./Login";
import Register from "./Register";
import Dashboard from "./Dashboard";
import Pending from "./Pending";
import Profile from "./Profile";
import AdminPanel from "./AdminPanel";
import Home from "./Home";

export default function App() {
  const [user, setUser] = useState(null);
  const [approved, setApproved] = useState(false);
  const [emailVerified, setEmailVerified] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setLoading(true);

      if (currentUser) {
        try {
          await reload(currentUser);

          // 🔹 Firestore-ból lekérjük az user adatait
          const userDocRef = doc(db, "users", currentUser.uid);
          const userDoc = await getDoc(userDocRef);
          const userData = userDoc.exists() ? userDoc.data() : {};

          // ✅ Ha email megerősített, Firestore-ban is frissítjük
          if (currentUser.emailVerified && !userData.emailVerified) {
            await updateDoc(userDocRef, { emailVerified: true });
          }

          setApproved(userData.approved !== false);
          setEmailVerified(currentUser.emailVerified);
          setIsAdmin(userData.role === "admin");
        } catch (err) {
          console.error("Auth sync error:", err);
        }
      }

      setLoading(false);
    });

    return () => unsub();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center text-white text-xl">
        Betöltés...
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        {/* 🔹 Vendég oldalak */}
        {!user ? (
          <>
            <Route path="/" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="*" element={<Navigate to="/" />} />
          </>
        ) : (
          <>
            {/* 🔹 Email/jóváhagyás ellenőrzés */}
            {!emailVerified || !approved ? (
              <>
                <Route path="/pending" element={<Pending />} />
                <Route path="*" element={<Navigate to="/pending" />} />
              </>
            ) : (
              <>
                {/* 🔹 Normál felhasználói útvonalak */}
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/home" element={<Home />} />

                {/* 🔹 Admin panel (csak adminoknak) */}
                {isAdmin && <Route path="/admin" element={<AdminPanel />} />}

                {/* 🔹 Redirect minden másra */}
                <Route path="*" element={<Navigate to="/dashboard" />} />
              </>
            )}
          </>
        )}
      </Routes>
    </Router>
  );
}
