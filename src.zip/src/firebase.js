// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDkAPuEjUXhyvRPAJQctM15hhLNBuJZjz4",
  authDomain: "parkolas-felugyelet.firebaseapp.com",
  projectId: "parkolas-felugyelet",
  storageBucket: "parkolas-felugyelet.appspot.com",
  messagingSenderId: "108611864581",
  appId: "1:108611864581:web:a97f251f22263ce67ff46c"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
