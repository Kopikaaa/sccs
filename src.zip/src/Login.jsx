import { useState } from "react";
import { auth, db } from "./firebase";
import {
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
} from "firebase/auth";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { Link, useNavigate } from "react-router-dom";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");
    setLoading(true);

    try {
      const ref = doc(db, "usernames", username);
      const snap = await getDoc(ref);

      if (!snap.exists()) {
        setError("❌ Nincs ilyen felhasználónév!");
        setLoading(false);
        return;
      }

      const { email } = snap.data();
      const persistence = rememberMe
        ? browserLocalPersistence
        : browserSessionPersistence;

      await setPersistence(auth, persistence);
      const userCredential = await signInWithEmailAndPassword(
        auth,
        email,
        password
      );

      const user = userCredential.user;
      await user.reload(); // 🔄 Frissítjük az auth adatokat

      // 🔍 Frissítjük Firestore-ban, ha az email megerősített
      if (user.emailVerified) {
        await updateDoc(doc(db, "users", user.uid), { emailVerified: true });
      }

      // 🔐 Ha nincs megerősítve az email, vagy nem hagyta jóvá admin
      const userDoc = await getDoc(doc(db, "users", user.uid));
      const data = userDoc.data();

      if (!user.emailVerified || data.emailVerified === false) {
        navigate("/pending");
      } else if (data.approved === false) {
        navigate("/pending");
      } else {
        navigate("/dashboard");
      }
    } catch (err) {
      console.error(err);
      if (
        err.code === "auth/invalid-credential" ||
        err.code === "auth/wrong-password"
      ) {
        setError("❌ Hibás jelszó vagy felhasználónév!");
      } else {
        setError("⚠️ Hiba történt: " + err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  // 🔑 Jelszó-emlékeztető
  const handleForgotPassword = async () => {
    setError("");
    setMessage("");
    try {
      if (!username) {
        setError("Add meg a felhasználóneved!");
        return;
      }

      const ref = doc(db, "usernames", username);
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        setError("❌ Nincs ilyen felhasználó!");
        return;
      }

      const { email } = snap.data();
      await sendPasswordResetEmail(auth, email);
      setMessage(`📧 Jelszó-visszaállító e-mail elküldve a(z) ${email} címre.`);
    } catch (err) {
      console.error(err);
      setError("Hiba történt: " + err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-800 to-blue-900">
      <div className="bg-slate-900 text-white p-8 rounded-2xl shadow-2xl w-full max-w-md border border-blue-600">
        <h1 className="text-3xl font-bold text-center text-blue-400 mb-6">
          Bejelentkezés
        </h1>

        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          <input
            type="text"
            placeholder="Felhasználónév"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="bg-slate-800 border border-gray-600 focus:border-blue-500 rounded-lg px-3 py-2 text-white"
            required
          />
          <input
            type="password"
            placeholder="Jelszó"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="bg-slate-800 border border-gray-600 focus:border-blue-500 rounded-lg px-3 py-2 text-white"
            required
          />

          <label className="flex items-center text-sm text-gray-300">
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="mr-2 accent-blue-500"
            />
            Jegyezzen meg
          </label>

          <button
            type="submit"
            disabled={loading}
            className={`${
              loading ? "bg-blue-400" : "bg-blue-600 hover:bg-blue-700"
            } text-white py-2 rounded-lg font-semibold transition`}
          >
            {loading ? "Bejelentkezés..." : "Bejelentkezés"}
          </button>
        </form>

        {error && <p className="text-red-400 mt-3 text-center">{error}</p>}
        {message && <p className="text-green-400 mt-3 text-center">{message}</p>}

        <button
          onClick={handleForgotPassword}
          className="text-sm text-blue-400 hover:underline mt-4 block mx-auto"
        >
          Elfelejtett jelszó?
        </button>

        <p className="text-sm text-center mt-4 text-gray-400">
          Nincs még fiókod?{" "}
          <Link to="/register" className="text-blue-400 hover:underline">
            Regisztráció
          </Link>
        </p>
      </div>
    </div>
  );
}
