import { useState } from "react";
import { auth, db } from "./firebase";
import {
  createUserWithEmailAndPassword,
  updateProfile,
  sendEmailVerification,
} from "firebase/auth";
import { setDoc, doc } from "firebase/firestore";
import { Link, useNavigate } from "react-router-dom";

export default function Register() {
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(res.user, { displayName });

      // Email megerősítés küldése
      await sendEmailVerification(res.user);

      // Firestore user mentése
      await setDoc(doc(db, "users", res.user.uid), {
        uid: res.user.uid,
        displayName,
        username,
        email,
        role: "user",
        approved: false, // admin jóváhagyás szükséges
        emailVerified: false,
        createdAt: new Date(),
      });

      // Felhasználónév mentése külön is
      await setDoc(doc(db, "usernames", username), { email });

      alert(
        "✅ Sikeres regisztráció!\n\n📩 Kérjük, erősítsd meg az e-mail címedet, mielőtt bejelentkezel."
      );
      navigate("/");
    } catch (err) {
      console.error(err);
      setError("Hiba: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-800 to-blue-900">
      <div className="bg-slate-900 text-white p-8 rounded-2xl shadow-2xl w-full max-w-md border border-blue-600">
        <h1 className="text-3xl font-bold text-center text-blue-400 mb-6">
          Regisztráció
        </h1>

        <form onSubmit={handleRegister} className="flex flex-col gap-4">
          <input
            type="text"
            placeholder="Teljes név"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            className="bg-slate-800 border border-gray-600 focus:border-blue-500 rounded-lg px-3 py-2 text-white"
            required
          />
          <input
            type="text"
            placeholder="Felhasználónév"
            value={username}
            onChange={(e) => setUsername(e.target.value.trim())}
            className="bg-slate-800 border border-gray-600 focus:border-blue-500 rounded-lg px-3 py-2 text-white"
            required
          />
          <input
            type="email"
            placeholder="E-mail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="bg-slate-800 border border-gray-600 focus:border-blue-500 rounded-lg px-3 py-2 text-white"
            required
          />
          <input
            type="password"
            placeholder="Jelszó"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="bg-slate-800 border border-gray-600 focus:border-blue-500 rounded-lg px-3 py-2 text-white"
            required
          />

          <button
            type="submit"
            disabled={loading}
            className={`${
              loading ? "bg-blue-400" : "bg-blue-600 hover:bg-blue-700"
            } text-white py-2 rounded-lg font-semibold transition`}
          >
            {loading ? "Regisztráció..." : "Regisztráció"}
          </button>
        </form>

        {error && <p className="text-red-400 mt-3">{error}</p>}

        <p className="text-sm text-center mt-4 text-gray-400">
          Már van fiókod?{" "}
          <Link to="/" className="text-blue-400 hover:underline">
            Bejelentkezés
          </Link>
        </p>
      </div>
    </div>
  );
}
