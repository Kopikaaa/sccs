import { useEffect, useState, useRef } from "react";
import { auth, db } from "./firebase";
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  updateDoc,
  doc,
  getDoc,
} from "firebase/firestore";
import { useNavigate, useLocation, Link } from "react-router-dom";

// Lucide ikonok
import { Bell, Shield, User, LogOut, Car } from "lucide-react";

export default function Navbar({ pendingCount = 0 }) {
  const [name, setName] = useState("Felhasználó");
  const [unreadCount, setUnreadCount] = useState(0);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const dropdownRef = useRef(null);

  // Felhasználó betöltése
  useEffect(() => {
    const loadUser = async () => {
      if (!auth.currentUser) return;
      const ref = doc(db, "users", auth.currentUser.uid);
      const snap = await getDoc(ref);

      if (snap.exists()) {
        const data = snap.data();
        setName(
          data.displayName ||
            data.username ||
            auth.currentUser.displayName ||
            "Felhasználó"
        );
        setIsAdmin(data.role === "admin");
      } else {
        setName(auth.currentUser.displayName || "Felhasználó");
        setIsAdmin(false);
      }
    };
    loadUser();
  }, [auth.currentUser]);

  // Értesítések figyelése
  useEffect(() => {
    if (!auth.currentUser) return;
    const uid = auth.currentUser.uid;

    const q = query(
      collection(db, "notifications"),
      where("target", "in", ["all", uid]),
      orderBy("createdAt", "desc")
    );

    const unsub = onSnapshot(q, (snap) => {
      const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setNotifications(data);
    });

    return () => unsub();
  }, [auth.currentUser]);

  // Olvasatlan értesítések számítása
  useEffect(() => {
    if (!auth.currentUser) return;
    const uid = auth.currentUser.uid;
    const count = notifications.filter(
      (n) => !(n.readBy && Array.isArray(n.readBy) && n.readBy.includes(uid))
    ).length;
    setUnreadCount(count);
  }, [notifications, auth.currentUser]);

  // Dropdown kezelése
  useEffect(() => {
    const handleOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    };
    window.addEventListener("click", handleOutside);
    return () => window.removeEventListener("click", handleOutside);
  }, []);

  // Kijelentkezés
  const handleLogout = async () => {
    await auth.signOut();
    navigate("/");
  };

  // Értesítések megnyitása
  const handleOpenNotifications = () => {
    setDropdownOpen((prev) => !prev);
    if (!auth.currentUser) return;
    const uid = auth.currentUser.uid;
    notifications.slice(0, 10).forEach(async (n) => {
      try {
        const readBy = n.readBy || [];
        if (!readBy.includes(uid)) {
          await updateDoc(doc(db, "notifications", n.id), {
            readBy: [...readBy, uid],
          });
        }
      } catch (err) {
        console.warn(err);
      }
    });
    setUnreadCount(0);
  };

  return (
    <nav className="bg-gray-950 text-gray-100 px-6 py-3 flex items-center justify-between shadow-md fixed top-0 left-0 right-0 z-40 border-b border-gray-800">
      {/* Bal oldal - logó */}
      <button
        onClick={() => navigate("/dashboard")}
        className="flex items-center gap-2 text-lg font-bold text-blue-400 hover:text-blue-300 transition"
      >
        <Car className="w-6 h-6 text-blue-400" />
        <span className="text-white font-semibold">PF</span> Parkolás Felügyelet
      </button>

      {/* Jobb oldal - ikonok */}
      <div className="flex items-center gap-4">
        {/* Értesítések */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={handleOpenNotifications}
            className="relative p-2 rounded hover:bg-gray-800 transition"
            title="Értesítések"
          >
            <Bell className="w-5 h-5 text-gray-200" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold rounded-full px-1.5">
                {unreadCount}
              </span>
            )}
          </button>

          {dropdownOpen && (
            <div className="absolute right-0 mt-2 w-80 bg-gray-900 text-gray-100 rounded-lg shadow-xl overflow-hidden border border-gray-700">
              <div className="p-3 border-b border-gray-700 font-semibold bg-gray-800 text-blue-300">
                Értesítések
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="p-4 text-sm text-gray-400 text-center">
                    Nincs új értesítés.
                  </div>
                ) : (
                  notifications.map((n) => {
                    const title =
                      n.title ||
                      n.message ||
                      "Értesítés";
                    const lower = title.toLowerCase();
                    const isRejected =
                      lower.includes("elutas") || lower.includes("rejected");
                    const isAccepted =
                      lower.includes("elfogad") ||
                      lower.includes("jóváhagy") ||
                      lower.includes("approved");
                    return (
                      <div
                        key={n.id}
                        className="p-3 border-b border-gray-800 hover:bg-gray-800 transition flex items-start gap-3"
                      >
                        <div
                          className={`flex items-center justify-center w-7 h-7 rounded-full text-white ${
                            isRejected
                              ? "bg-red-500"
                              : isAccepted
                              ? "bg-green-500"
                              : "bg-blue-500"
                          }`}
                        >
                          {isRejected ? "✖" : isAccepted ? "✔" : "ℹ"}
                        </div>
                        <div className="flex-1">
                          <div className="font-medium text-gray-200">
                            {title}
                          </div>
                          <div className="text-sm text-gray-400 mt-1">
                            {n.body || ""}
                          </div>
                          <div className="text-xs text-gray-500 mt-1">
                            {n.createdAt?.toDate
                              ? n.createdAt.toDate().toLocaleString()
                              : ""}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>

        {/* Admin pajzs */}
        {isAdmin && (
          <button
            onClick={() => navigate("/admin")}
            title="Admin panel"
            className="relative p-2 rounded hover:bg-gray-800 transition"
          >
            <Shield className="w-5 h-5 text-blue-400" />
            {pendingCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold rounded-full px-1.5">
                {pendingCount}
              </span>
            )}
          </button>
        )}

        {/* Profil */}
        <Link
          to="/profile"
          className="flex items-center gap-1 text-sm font-medium hover:text-blue-300 transition"
        >
          <User className="w-5 h-5" />
          Profil
        </Link>

        {/* Kijelentkezés */}
        <button
          onClick={handleLogout}
          className="flex items-center gap-1 bg-red-600 hover:bg-red-700 px-4 py-1 rounded-lg text-white text-sm font-semibold transition"
        >
          <LogOut className="w-4 h-4" />
          Kijelentkezés
        </button>
      </div>
    </nav>
  );
}
