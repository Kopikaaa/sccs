import { useEffect, useState } from "react";
import { auth, db } from "./firebase";
import { doc, onSnapshot } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import { useNavigate } from "react-router-dom";

export default function Pending() {
  const [verified, setVerified] = useState(false);
  const [approved, setApproved] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    let unsubUser = null;

    const checkUser = async () => {
      onAuthStateChanged(auth, async (user) => {
        if (!user) {
          navigate("/");
          return;
        }

        // Valós idejű frissítés Firestore-ból (admin jóváhagyás)
        const userRef = doc(db, "users", user.uid);
        unsubUser = onSnapshot(userRef, async (snap) => {
          if (snap.exists()) {
            const data = snap.data();
            setApproved(data.approved || false);
          }

          // Email-verifikáció újratöltése biztonságosan
          await user.reload();
          setVerified(user.emailVerified);
          setLoading(false);

          // Ha minden rendben -> dashboard
          if (user.emailVerified && snap.exists() && snap.data().approved) {
            navigate("/dashboard");
          }
        });
      });
    };

    checkUser();
    return () => {
      if (unsubUser) unsubUser();
    };
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-950 text-white">
        <p>Betöltés...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col items-center justify-center px-6 text-center">
      <div className="bg-gray-900 border border-gray-700 rounded-2xl p-8 max-w-lg shadow-lg">
        <h1 className="text-3xl font-bold text-blue-400 mb-4">
          Fiók jóváhagyás alatt
        </h1>
        {!verified ? (
          <>
            <p className="text-gray-300 mb-3">
              📧 Kérjük, erősítsd meg az e-mail címedet a regisztrációkor kapott
              levélben.
            </p>
            <p className="text-sm text-gray-400">
              Amint megerősítetted, automatikusan továbbítunk.
            </p>
          </>
        ) : !approved ? (
          <>
            <p className="text-gray-300 mb-3">
              ⏳ Az e-mail címed megerősítve, de az admin jóváhagyására még
              várakozol.
            </p>
            <p className="text-sm text-gray-400">
              Amint az admin elfogadja a fiókod, automatikusan belépsz.
            </p>
          </>
        ) : (
          <p className="text-green-400 font-semibold">
            ✅ Minden rendben, átirányítás folyamatban...
          </p>
        )}
      </div>
    </div>
  );
}
