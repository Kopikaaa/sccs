import React, { useState, useEffect } from "react";
import { auth, db } from "./firebase";
import {
  doc,
  getDoc,
  addDoc,
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  updateDoc,
} from "firebase/firestore";
import {
  updatePassword,
  updateEmail,
  sendEmailVerification,
} from "firebase/auth";
import Navbar from "./Navbar";

export default function Profile() {
  const [profile, setProfile] = useState(null);
  const [newName, setNewName] = useState("");
  const [reason, setReason] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [requests, setRequests] = useState([]);
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");

  // 🔹 Profil betöltése
  useEffect(() => {
    const loadProfile = async () => {
      if (!auth.currentUser) return;
      const refDoc = doc(db, "users", auth.currentUser.uid);
      const snap = await getDoc(refDoc);
      setProfile(snap.exists() ? snap.data() : {});
    };
    loadProfile();
  }, []);

  // 🔹 Névváltoztatási kérelmek figyelése
  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(
      collection(db, "nameChangeRequests"),
      where("userId", "==", auth.currentUser.uid),
      orderBy("timestamp", "desc")
    );
    const unsub = onSnapshot(q, (snap) => {
      setRequests(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    return () => unsub();
  }, []);

  // 🔹 Névváltoztatási kérelem küldése
  const handleSubmitRequest = async () => {
    if (!newName.trim() || !reason.trim()) {
      setError("❌ Tölts ki minden mezőt!");
      return;
    }

    try {
      const requestRef = await addDoc(collection(db, "nameChangeRequests"), {
        userId: auth.currentUser.uid,
        oldName: profile?.displayName || profile?.username || "Nincs megadva",
        newName,
        reason,
        status: "pending",
        timestamp: serverTimestamp(),
      });

      await addDoc(collection(db, "notifications"), {
        type: "nameChange",
        message: `${profile?.displayName || "Ismeretlen"} névváltoztatási kérelmet küldött.`,
        userId: auth.currentUser.uid,
        relatedId: requestRef.id,
        forAdmin: true,
        createdAt: serverTimestamp(),
        readBy: [],
      });

      setMessage("✅ Névváltoztatási kérelem elküldve az adminoknak!");
      setError("");
      setNewName("");
      setReason("");
    } catch (err) {
      console.error(err);
      setError("Hiba: " + err.message);
    }
  };

  // 🔹 Email módosítás
  const handleChangeEmail = async () => {
    if (!newEmail) return setError("Add meg az új e-mail címet!");
    try {
      await updateEmail(auth.currentUser, newEmail);
      await sendEmailVerification(auth.currentUser);

      // ✅ Firestore frissítése: emailVerified újra false
      await updateDoc(doc(db, "users", auth.currentUser.uid), {
        email: newEmail,
        emailVerified: false,
      });

      await addDoc(collection(db, "notifications"), {
        target: auth.currentUser.uid,
        title: "📧 E-mail frissítve",
        body: `E-mail címed frissítve: ${newEmail}`,
        createdAt: serverTimestamp(),
        readBy: [],
      });

      setMessage("✅ E-mail frissítve és megerősítő e-mail elküldve!");
      setError("");
      setNewEmail("");
    } catch (err) {
      console.error(err);
      setError("E-mail frissítés hiba: " + err.message);
    }
  };

  // 🔹 Jelszó módosítás
  const handleChangePassword = async () => {
    if (!newPassword) return setError("Add meg az új jelszót!");
    try {
      await updatePassword(auth.currentUser, newPassword);
      setMessage("✅ Jelszó sikeresen megváltoztatva.");
      setError("");
      setNewPassword("");
    } catch (err) {
      console.error(err);
      setError("Jelszó frissítés hiba: " + err.message);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white pt-20">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-gray-900 border border-gray-700 shadow-lg rounded-2xl p-6">
          <h2 className="text-2xl font-bold text-blue-400 mb-6">Profil beállítások</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Bal oldali rész */}
            <div>
              <p className="text-sm text-gray-400 mb-1">Felhasználónév</p>
              <p className="font-semibold text-lg mb-4">
                {profile?.username || auth.currentUser?.displayName || auth.currentUser?.email}
              </p>

              <p className="text-sm text-gray-400 mb-1">E-mail</p>
              <p className="text-sm text-gray-300">{auth.currentUser?.email}</p>

              <p className="text-sm text-gray-400 mt-4 mb-1">E-mail státusz</p>
              <p className="text-sm">
                {auth.currentUser?.emailVerified ? "✅ Megerősítve" : "❌ Nincs megerősítve"}
              </p>
            </div>

            {/* Jobb oldali rész */}
            <div className="md:col-span-2 space-y-8">
              {/* Névváltoztatás */}
              <div>
                <h3 className="font-semibold text-blue-300 mb-2">Név módosítás</h3>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-blue-500"
                  placeholder="Új név..."
                />
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 mt-3 text-white focus:ring-2 focus:ring-blue-500"
                  placeholder="Indoklás..."
                />
                <button
                  onClick={handleSubmitRequest}
                  className="mt-3 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg font-semibold"
                >
                  Kérelem elküldése
                </button>
              </div>

              {/* E-mail / jelszó módosítás */}
              <div className="border-t border-gray-700 pt-6">
                <h3 className="font-semibold text-blue-300 mb-3">E-mail / Jelszó módosítása</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <input
                      type="email"
                      placeholder="Új e-mail..."
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-green-500"
                    />
                    <button
                      onClick={handleChangeEmail}
                      className="mt-2 bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg font-semibold"
                    >
                      E-mail frissítése
                    </button>
                  </div>
                  <div>
                    <input
                      type="password"
                      placeholder="Új jelszó..."
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-green-500"
                    />
                    <button
                      onClick={handleChangePassword}
                      className="mt-2 bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg font-semibold"
                    >
                      Jelszó módosítása
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {message && <div className="mt-4 text-green-500">{message}</div>}
          {error && <div className="mt-4 text-red-500">{error}</div>}
        </div>
      </div>
    </div>
  );
}
